package fighters.base;

public interface Attackable {
	public abstract int attack(Unit e);
}