package fighters.base;

public interface Guardable {
	public abstract void guard();
}
