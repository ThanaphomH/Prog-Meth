package discount;

public interface PercentDiscountable extends Sellable{
	public abstract int calcDiscountPerPiece();
}
