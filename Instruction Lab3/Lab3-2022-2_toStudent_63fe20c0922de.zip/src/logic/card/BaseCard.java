package logic.card;

import logic.game.CardSymbol;
import logic.game.CardColor;

//You CAN modify the first line
public class BaseCard {
    // TODO Implement here

}
